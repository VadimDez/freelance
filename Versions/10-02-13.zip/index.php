<?php
    session_start();
	include('dbConnect.php');
    // categorie
	$query = mysql_query("SELECT * FROM categorie") or die(mysql_error());
	while($row = mysql_fetch_assoc($query))
	{
		$categorie .= '<li><a href="#">' . $row['nomeCat'] . '</a></li>';
	}
	// stampo ogni annuncio
	$query = mysql_query("SELECT * FROM users, project WHERE users.idUser = project.idUser ORDER BY dataProj DESC") or die(mysql_error());
	if(mysql_num_rows($query) == 0)
	{
		$projects ='0 progetti.';
	}
	else
	{
		while($row = mysql_fetch_assoc($query))
		{
			// formattazione per ogni annuncio
			$projects .= 
				'<div style="background-color:#999">
					<div>
						<a href="project.php?id=' . $row['idProj'] . '">' . $row['nomeProj'] .'</a>
					</div>
					<div>
						data, qualcosa, info..
					</div>
					<div>
						' . $row['descrizione'] . '
					</div>
					<div>
						' . $row['dataProj'] . '
					</div>
				</div><br/>';
		}
	}
	// fine stampa annuncio

?>

<html>
    <head>
        <title>Home page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Bootstrap -->
   		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" type="text/css" href="style/main.css" >
    </head>
    <body>
            <?php
				include('template/header.html');
			 	include('template/main.html'); 
				include('template/footer.html'); 
			?>
            <script src="bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>