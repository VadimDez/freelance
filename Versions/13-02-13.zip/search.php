<?php

	if(isset($_GET['cat']))
	{
		include('model.php');
		$categoria 	= $_GET['cat'];
		$model = new ModelSearchCategory;
		if(isset($_GET['page']))
		{
			$page = $_GET['page'];
			$model->searchCategory($categoria,$page);
		}
		else
		{
			$model->searchCategory($categoria);	
		}
		
		
	}

?>