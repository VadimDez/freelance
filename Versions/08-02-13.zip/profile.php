<?php

if(include('check.php'))
{
    include('dbConnect.php');
	if(isset($_GET['id']))
	{
		$idUser = $_GET['id'];
	}
	else
	{
    	$idUser = $_SESSION['idUser'];
	}
    $query = mysql_query("SELECT * FROM users WHERE users.idUser = '$idUser'");
    $row = mysql_fetch_assoc($query);
    
    // info =============================================================
    $name      		= $row['name'];
    $secondname 	= $row['secondname'];
	$photo			= $row['img'];
	$tipo			= $row['tipo'];
	$city			= $row['city'];
	$dataReg		= $row['dataRegistrazione'];
	$day			= $row['day'];
	$month			= $row['month'];
	$year			= $row['year'];
	
	// numero progetti partecipanti
	$numero			= mysql_query("SELECT * FROM candidati WHERE idUser='$idUser'") or die(mysql_error());
	$numProjPart	= mysql_num_rows($numero);
	
	// numero progetti vinti
	$numero			= mysql_query("SELECT * FROM vincenti WHERE idUser='$idUser'") or die(mysql_error());
	$numProjWin		= mysql_num_rows($numero);
	
	// numero progetti pubblicati
	$numero			= mysql_query("SELECT * FROM project WHERE idUser='$idUser'") or die(mysql_error());
	$numProjPubb	= mysql_num_rows($numero);
    // ==================================================================
}
else
{
    header('Location:login.php');
}

mysql_close();
?>

<html>
<head>
	<title>Profilo di <?php print "$name $secondname";?></title>
</head>
<body>
    <?php
    	include('template/header.html');
		include('template/profile.html');
		include('template/footer.html');
	?>
</body>
</html>