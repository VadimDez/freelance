<?php
	if(include('check.php'))
	{
		if(isset($_GET['proj']))
		{
			$idProj = $_GET['proj'];
		}
		else
		{
			if(isset($_POST['ok']) && isset($_POST['proj']) )
			{
				$idProj = $_POST['proj'];
				$idUser = $_SESSION['idUser'];
				include('dbConnect.php');
				mysql_query("DELETE FROM candidati WHERE idUser='$idUser' AND idProj='$idProj'") or die(mysql_error());
				header('location:project.php?id=' . $idProj);	
			}
		}
	}
	else
	{
		header('location:login.php');	
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Controllo</title>
</head>
	sicuro?
    <form action="leave.php" method="post">
    	<input type="hidden" value="<?php print "$idProj" ?>" name="proj" />
    	<input type="submit" value="Si" name="ok" />
    </form>
<body>
</body>
</html>