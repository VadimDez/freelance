<?php
	session_start();
	include('dbConnect.php');
	
	// variabili
	$projects = '';
	
	
	if(isset($_GET['id']))
	{
		// se passa id del progetto
		$idProj = $_GET['id'];
		
		$query = mysql_query("SELECT * FROM project,users WHERE idProj = '$idProj' AND project.idUser = users.idUser") or die(mysql_error());
		if(mysql_num_rows($query) == 0 )
		{
			$projects = "il prog. e' stato cancellato o non esiste";
		}
		else
		{
			$row = mysql_fetch_assoc($query);
			$projects .= '<div style="background-color:yellow;"><div style="float:left;"><a href="profile.php?id=' . $row['idUser'] . '">' . $row['name'] . '</a></div><div style="background-color:grey;">Titolo: ' . $row['nomeProj'];
			// controllo per il tasto per candidarsi
			if(isset($_SESSION['idUser'])) // se ha gia fatto login
			{
				$idUser = $_SESSION['idUser'];
				// controllo se e' il proprietario
				$candidato = mysql_query("SELECT idUser FROM project WHERE idProj='$idProj' AND idUser='$idUser'") or die(mysql_error());
				if(mysql_num_rows($candidato) == 0)
				{
					$proprietario = false;
					// controllo se utente ha gia partecipato
					$candidato = mysql_query("SELECT idUser FROM candidati WHERE idProj='$idProj' AND idUser='$idUser'") or die(mysql_error());
					if(mysql_num_rows($candidato) == 0)
					{
						// non ha ancora partecipato - aggiungo bottone per candidarsi
						$projects .= '<a href="join.php?proj=' . $idProj . '"><input type="submit" value="Candidarsi"/></a>';
					}
					else
					{
						// sta partecipando - aggiungo bottone "esci"
						$projects .= '<a href="leave.php?proj=' . $idProj . '"><input type="submit" value="Esci"/></a>';
					}
				}
				else
				{
					$proprietario = true;
				}
			
			}
			// stampo progetto
			$projects .= '</div>Tipo:' . $row['tipoProj'] . '<br/>Categoria:' . $row['idCategoria'] . '<br/>Descrizione:' . $row['descrizione'] . '<br/>Richieste:' . $row['richieste'] . '</div>';
			
			$comments = '';
			$query = mysql_query("SELECT * FROM candidati, users WHERE idProj='$idProj' AND candidati.idUser = users.idUser") or die(mysql_error());
			if(mysql_num_rows($query) == 0)
			{
				// in caso se non ci sono proposte
				$comments .= "Non ci sono proposte";	
			}
			else
			{
				
					if($proprietario)
					{
						// controllo se proprietario ha gia' sceglto il candidato
						$controllo = mysql_query("SELECT idUser FROM vincenti WHERE idProj='$idProj'") or die(mysql_error());
						if(mysql_num_rows($controllo) < 1)
						{
							// se no:
							$decide = false;
						}
						else
						{
							// se si:
							$decide = true;
						}
					}
				
				// stampo i commenti , cioe' proposte
				while($row = mysql_fetch_assoc($query))
				{
					$comments .= '<div><a href="profile.php?id=' . $row['idUser'] .'">' . $row['name'] . $row['secondname'] . '</a></div>';
					
					if(!$decide && $proprietario == true)
					{
						$comments .= '<form action="take.php?proj=' . $idProj . '" method="post"><input type="hidden" value="' . $row['idUser'] . '" name="usr" /><input type="submit" value="Scegli" name="take"/></form>';
					}
					else
					{
						
					}
					
					$comments .= '<div>' . $row['comment'] . '</div>';
				}
			}
			
		}
	}
	else
	{
		$query = mysql_query("SELECT * FROM project ORDER BY dataProj DESC") or die(mysql_error());
		if(mysql_num_rows($query) == 0 )
		{
			$projects = "non ci sono progetti da fare";
		}
		else
		{
			while($row = mysql_fetch_assoc($query))
			{
				// stampo la lista dei progetti
				$projects .= '<div><a href="project.php?id=' . $row['idProj'] . '">' . $row['nomeProj'] . '</a></div> <br/>';
			}
		}
	}
	mysql_close();
?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="style/main.css" >
</head>
	<body>
    	<?php
		
		include('template/header.html');
		if(isset($_GET['id']))
		{
			include('template/project.html');
		}
		else
		{
			include('template/projects.html');
		}
		include('template/footer.html');
		
		?>
        
        
        <script type="text/javascript" src="script/jquery-1.8.3.js"></script>
    </body>

</html>