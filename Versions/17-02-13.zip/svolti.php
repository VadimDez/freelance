<?php
	session_start();
	if(isset($_GET['id']))
	{
		  $idUser = $_GET['id'];
	}
	else
	{
		if(isset($_SESSION['idUser']))
		{
			$idUser = $_SESSION['idUser'];
		}
		else
		{
			header('location:index.php');
			exit();
		}
	}
	
	include('dbConnect.php');
	if($idUser && !isset($_POST['action']))
	{
		
		$query = mysql_query("SELECT * FROM vincenti,project WHERE vincenti.idProj=project.idProj AND vincenti.idUser='$idUser' ORDER BY project.dataProj ASC") or die(mysql_error());
		if(mysql_num_rows($query) == 0)
		{
			$risultato = "Non ci sono progetti";	
		}
		else
		{
			$risultato = "<div>";
			while($infoProj = mysql_fetch_assoc($query))
			{
					$idProj 	= $infoProj['idProj'];
					//$query2 	= mysql_query("SELECT * FROM project WHERE idProj='$idProj' ORDER BY dataProj DESC") or die(mysql_error());
					//$infoProj 	= mysql_fetch_assoc($query2);
					
					if($infoProj['confirmed'] == 0)
					{
						// se e' da confermare
						$style = "pink";
					}
					else
					{
						$style = "white";
					}
					
					$risultato .= '<div style="background-color:' . $style . ';"><a href="project.php?id=' . $idProj . '">' . $infoProj['nomeProj'] . '</a>';
					if($infoProj['confirmed'] == 0 && ($_SESSION['idUser'] == $idUser))
					{
						$risultato .= '<form action="svolti.php" method="post"><input type="hidden" name="action" value="' . $idProj . '"/><input type="submit" name="confirm" value="Conferma"/></form>';
						$risultato .= '<form action="svolti.php" method="post"><input type="hidden" name="action" value="' . $idProj . '"/><input type="submit" name="refuse" value="Rifiuta"/></form>';
					}
					$risultato .= '</div>';
			}
			$risultato .= "</div>";
		}
	}
	else
	{
		// in caso se preme uno dei bottoni
		if(isset($_POST['action']))
		{
			$idProj = $_POST['action'];
			$query = mysql_query("SELECT * FROM vincenti WHERE idProj='$idProj' AND idUser='$idUser'") or die(mysql_error());
			if(mysql_num_rows($query) == 1)
			{
				// se conferma
				if(isset($_POST['confirm']))
				{
					mysql_query("UPDATE vincenti SET confirmed='1'") or die(mysql_error());
				}
				else
				{
					//se rifiuta
					if(isset($_POST['refuse']))
					{
						mysql_query("DELETE FROM vincenti WHERE idUser='$idUser' AND idProj='$idProj'") or die(mysql_error());
					}
				}
			}
			
			header('location:project.php?id=' . $idProj);
			exit();
		}
		else
		{		
			header('location:index.php');
			exit();
		}
	}
	
	
?>


<div>
	campi...
</div>

<?php print $risultato; ?>