<?php

if(include('check.php'))
{
    include('dbConnect.php');
	if(isset($_GET['id']))
	{
		$idUser = $_GET['id'];
	}
	else
	{
    	$idUser = $_SESSION['idUser'];
	}
    $query = mysql_query("SELECT * FROM users WHERE users.idUser = '$idUser'");
    $row = mysql_fetch_assoc($query);
    
    // info =============================================================
    $name       = $row['name'];
    $secondname = $row['secondname'];
	$photo		= $row['img'];
	$country	= $row['country'];
	$city		= $row['city'];
    // ==================================================================
}
else
{
    header('Location:login.php');
}

mysql_close();
?>

<html>
<head>
	<title>Profilo di <?php print "$name $secondname";?></title>
</head>
<body>
    <?php
    	include('template/header.html');
		include('template/profile.html');
		include('template/footer.html');
	?>
</body>
</html>