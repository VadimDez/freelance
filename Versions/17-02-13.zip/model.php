<?php
	session_start();
	// gestione database
	class myConnection
	{
		public function connect()
		{
			$mysql_hostname = "localhost"; // name mysql host
			$mysql_user		= "root"; // user mysql
			$mysql_password = ""; // pass
			$mysql_database = "freelance"; //mysql db
			$db				= mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Errore di connessione con la database");
			$select 		= mysql_select_db($mysql_database, $db) or die("Errore della selezione della databese");
			if($db && $select)
			{
				return true;
			}
			else
			{
				return false;	
			}
		}
		
		public function close()
		{
			mysql_close();
		}
	}
	
	// cerca 
	class ModelSearchCategory
	{
		function searchCategory($category,$page = 1)
		{
			$page = 20*$page;
			$query = mysql_query("SELECT * FROM project, categorie WHERE idCategoria='$category' AND idCat='$category' ORDER BY dataProj DESC LIMIT $page") or die(mysql_error());
			if(mysql_num_rows($query) > 0)
			{
				while($row = mysql_fetch_assoc($query))
				{
					$text = $row['descrizione'];
					$text = substr($text,0,350);
					$risultato .= '<blockquote><div>
					<div>
						<a href="project.php?id=' . $row['idProj'] . '"><p>' . $row['nomeProj'] .'</p></a>
					</div>
					<div>
							<small>' . $row['nomeCat'] . '</small>
					</div>
					<div>
						<pre style="float:right;">' . $row['prezzo'] . '</pre>' . $text . '
					</div>
					<div>
						<small>' . $row['dataProj'] . '</small>
					</div>
				</div></blockquote><br/>';
					}
			}
			else
			{
				$risultato = 'Nessun annuncio.';
			}
			/*$cat = new home;
			$categorie = $cat->categorie();
			include('template/category_view.html');*/
			$this->loadViewSearch($risultato);
		}
		
		function loadViewSearch($ris)
		{
			$risultato = $ris;
			$cat = new home;
			$categorie = $cat->categorie();
			include('template/category_view.html');
		}
		
		function searchByWord($word)
		{
			$query = mysql_query("SELECT * FROM project, categorie WHERE project.categoria = categorie.idCat AND ( project.nomeProj LIKE '%$word%' OR project.descrizione LIKE '%$word%' OR project.richieste LIKE '%$word%' ) ORDER BY project.dataProj DESC") or die(mysql_error());
			if(mysql_num_rows($query) > 0)
			{
				while($row = mysql_fetch_assoc($query))
				{
					$text = $row['descrizione'];
					$text = substr($text,0,350);
					$projects .= 
						'<blockquote><div>
							<div>
								<a href="project.php?id=' . $row['idProj'] . '"><p>' . $row['nomeProj'] .'</p></a>
							</div>
							<div>
								<small>' . $row['nomeCat'] . '</small>
							</div>
							<div>
								<pre style="float:right;">' . $row['prezzo'] . '</pre>' . $text . '
							</div>
							<div>
								<small>' . $row['dataProj'] . '</small>
							</div>
						</div></blockquote><br/>';
				}
			}
			else
			{
				$projects = '0 risultati';	
			}
			$this->loadViewSearch($projects);
		}

	}
	
	// la classe per la pagina iniziale
	class home
	{
		
		function categorie()
		{
			$query = mysql_query("SELECT * FROM categorie") or die(mysql_error());
			while($row = mysql_fetch_assoc($query))
			{
				$categorie .= '<li><a href="search.php?cat=' . $row['idCat'] . '">' . $row['nomeCat'] . '</a></li>';
			}
			return $categorie;
		}
		
		function annunci($page = 1)
		{
			$page = 10 * $page;
			// stampo ogni annuncio
			$query = mysql_query("SELECT * FROM users, project, categorie WHERE users.idUser = project.idUser AND categorie.idCat = project.categoria ORDER BY dataProj DESC LIMIT $page") or die(mysql_error());
			if(mysql_num_rows($query) == 0)
			{
				$projects ='0 progetti.';
			}
			else
			{
				while($row = mysql_fetch_assoc($query))
				{
					$text = $row['descrizione'];
					$text = substr($text,0,350);
					// formattazione per ogni annuncio
					$projects .= 
						'<blockquote><div>
							<div>
							<pre style="float:right;">' . $row['prezzo'] . '</pre>
								<a href="project.php?id=' . $row['idProj'] . '"><p>' . $row['nomeProj'] .'</p></a>
								
							</div>
							<div>
								<small>' . $row['nomeCat'] . '</small>
							</div>
							<div>
								' . $text . '
							</div>
							<div>
								<small>' . $row['dataProj'] . '</small>
							</div>
						</div></blockquote><br/>';
					}
			}
			// fine stampa annuncio
			return $projects;
		}
		
		function pageCounter($page = 1)
		{
			// conto il numero degli annunci
			$query = mysql_query("SELECT COUNT(*) AS num FROM project") or die(mysql_error());
			$row = mysql_fetch_assoc($query);
			
			// ottengo intero
			$numPage = ($row['num'] / 10);
			if(!is_int($numPage))
			{
				$numPage += 1;
				$numPage = (int)$numPage;	
			}
			
			if($page <= $numPage && $page >= 1)
			{
				// pages
				$pages = '<div class="pagination pagination-centered">
				  <ul>
					<li';
				if($page == 1)
				{
					$pages .= ' class="disabled"';
				}
				$pages .= '><a href="index.php">&laquo;</a></li>';
				if($page >= 3)
				{
					for($c = $page-2;$c < $page; $c++)
					{
						$pages .= '<li><a href="index.php?page=' . $c . '">' . $c . '</a></li>';
					}
				}
				else
				{
					if($page >= 2)
					{
						$numero = $page-1;
						$pages .= '<li><a href="index.php?page=' . $numero . '">' . $numero . '</a></li>';
					}
				}
				$pages .= '<li class="active"><a href="#">' . $page . '</a></li>';
				
				if($page <= $numPage-2)
				{
					for($c = $page+1;$c < $page+3; $c++)
					{
						$pages .= '<li><a href="index.php?page=' . $c . '">' . $c . '</a></li>';
					}
				}
				else
				{
					if($page <= $numPage-1)
					{
						$numero = $page+1;
						$pages .= '<li><a href="index.php?page=' . $numero . '">' . $numero . '</a></li>';
					}
				}
					$pages .= '<li';
				if($page == $numPage)
				{
					$pages .= ' class="disabled"';
				}
				$pages .= '><a href="index.php?page=' . $numPage . '">&raquo;</a></li>
				  </ul>
				</div>';
			}
			else
			{
				$pages = 'Pagina numero <strong>' . $page . '</strong> non esiste';
			}
			return $pages;
		}
		
	}

?>