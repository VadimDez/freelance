<?php
	session_start();
	class myConnection
	{
		function connect()
		{
			$mysql_hostname = "localhost"; // name mysql host
			$mysql_user		= "root"; // user mysql
			$mysql_password = ""; // pass
			$mysql_database = "freelance"; //mysql db
			$db				= mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Errore di connessione con la database");
			$select 		= mysql_select_db($mysql_database, $db) or die("Errore della selezione della databese");
			if($db && $select)
			{
				return true;
			}
			else
			{
				return false;	
			}
		}
	}
	
	class ModelSearchCategory
	{
		
		
		function searchCategory($category,$page = 1)
		{
			if(connect())
			{
				$page = 20*$page;
				$query = mysql_query("SELECT * FROM project, categorie WHERE idCategoria='$category' AND idCat='$category' ORDER BY dataProj DESC LIMIT $page") or die(mysql_error());
				if(mysql_num_rows($query) > 0)
				{
					while($row = mysql_fetch_assoc($query))
					{
							$risultato .= '<blockquote><div>
						<div>
							<a href="project.php?id=' . $row['idProj'] . '"><p>' . $row['nomeProj'] .'</p></a>
						</div>
						<div>
							<small>' . $row['nomeCat'] . '</small>
						</div>
						<div>
							<pre style="float:right;">' . $row['prezzo'] . '</pre>' . $text . '
						</div>
						<div>
							<small>' . $row['dataProj'] . '</small>
						</div>
					</div></blockquote><br/>';
					}
				}
				else
				{
					$risultato = 'Nessun annuncio.';
				}
				include('template/category_view.html');
			}
			else
			{
				print "Errore";	
			}
		}
		

	}
	
	class home
	{
		
	}

?>