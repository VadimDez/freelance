<?php
    session_start();
	include('dbConnect.php');
    // variabili
    $projects ='';
    // end
    
	$query = mysql_query("SELECT * FROM users, project WHERE users.idUser = project.idUser") or die(mysql_error());
	if(mysql_num_rows($query) == 0)
	{
		$projects ='0 progetti.';
	}
	else
	{
		while($row = mysql_fetch_assoc($query))
		{
			// formattazione per ogni annuncio
			$projects .= '<div><a href="project.php?id=' . $row['idProj'] . '">' . $row['nomeProj'] .'</a></div>';
		}
	}

?>

<html>
    <head>
        <title>Home page</title>
    </head>
    <body>
            <?php
				include('template/header.html');
			 	include('template/main.html'); 
				include('template/footer.html'); 
			?>
    </body>
</html>