<?php
if(!include('check.php'))
{
	header('Location:login.php');
	exit;
}
else
{
	// variabili
	$myID = $_SESSION['idUser'];
	
	$projectName ='';
	$tipo ='';
	$categoria ='';
	$prezzo ='';
	$descrizione ='';
	$richieste ='';
	
	if(isset($_POST['done']))
	{
		$projectName = $_POST['projName'];
		$tipoProj	 = $_POST['tipoProj'];
		$categoria	 = $_POST['c'];
		$prezzo		 = $_POST['prezzo'];
		$descrizione = $_POST['d'];
		// pars
		
		$richieste	 = $_POST['r'];
		// pars
		
		// salvo in database
		include('dbConnect.php');
		
		mysql_query("INSERT INTO project(idProj,idUser,nomeProj,tipoProj,idCategoria,prezzo,descrizione,richieste) VALUES(NULL,'$myID', '$projectName', '$tipoProj', '$categoria', '$prezzo', '$descrizione', '$richieste')") or die(mysql_error());
		
		print "e stato aggiunto";
		
		// per levare il problema di aggiornamento
		/*echo '<script type="text/javascript">';
    	echo 'window.location.reload();';
    	echo '</script>';*/
	}
	
}

?>

<html>
	<head>
    	<title>Nuovo progetto</title>
    </head>
    <body>
    	<?php
			include('template/header.html');
			include('template/newproj.html');
			include('template/footer.html');
		?>
    </body>
</html>