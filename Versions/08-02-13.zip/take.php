<?php
	if(include('check.php'))
	{
		if(isset($_GET['proj']) && isset($_POST['take']) && isset($_POST['usr']))
		{
			$idProj = $_GET['proj'];
			$idSelected = $_POST['usr'];
		}
		else
		{
			if(isset($_POST['proj']) && isset($_POST['ok']) && isset($_POST['usr']))
			{
				
				$idProj = $_POST['proj'];
				$idSelected = $_POST['usr'];
				$idUser = $_SESSION['idUser'];
				
				include('dbConnect.php');
				$query = mysql_query("SELECT * FROM candidati WHERE idUser='$idSelected' AND idProj='$idProj'") or die(mysql_error());
				
				if(mysql_num_rows($query) == 1)
				{
					mysql_query("INSERT INTO vincenti(idUser, idProj) VALUES('$idSelected','$idProj')") or die(mysql_error());
					header('location:project.php?id=' . $idProj);
				}
				else
				{
					print "error!";	
					exit();
				}
			}
			else
			{
				header('location:index.php');
			}
		}
	}
	else
	{
		header('location:login.php');
	}
	

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
</head>
	Sicuro?
    <form method="post" action="take.php">
    	<input type="hidden" name="usr" value="<?php print "$idSelected"; ?>"/>
        <input type="hidden" name="proj" value="<?php print "$idProj"; ?>" />
        <input type="submit" value="Si" name="ok"/>
    </form>
<body>
</body>
</html>