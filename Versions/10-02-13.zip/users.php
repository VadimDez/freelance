<?php
	session_start();
    include('dbConnect.php');
    
    $query = mysql_query("SELECT * FROM users ORDER BY secondname");
    
    //lista per gli utenti
    $users ='';
    while($row = mysql_fetch_assoc($query))
    {
        $userId     = $row['idUser'];
        $name       = $row['name'];
        $secondname = $row['secondname'];
        $img        = $row['img'];
        $city       = $row['city'];
		$tipo    = $row['tipo'];
		if($tipo == 1)
		{
			$tipo = "Azienda";
		}
		else
		{
			$tipo = "Privato";	
		}
        
        
        $users .= '<table><tr><td><img src="' .  $img  . '" /></td><td valign="top"><a href="profile.php?id=' . $userId . '">' . $name . ' ' . $secondname . '</a><br/>' . $tipo . '<br/>' . $city . '</td></tr></table><hr/>';
    }

?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Utenti</title>
        <link rel="stylesheet" type="text/css" href="style/main.css" >
                <!-- ricerca -->
        <script type="text/javascript">
            function find()
            {
                if(window.XMLHttpRequest)
                {
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {
                    xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
                }
                
                xmlhttp.onreadystatechange = function()
                {
                    if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                        document.getElementById('result').innerHTML = xmlhttp.responseText;
                    }
                }
                
                xmlhttp.open('GET', 'searchFriend.php?search_name='+document.search.search_name.value, true);
                xmlhttp.send();
            }
        </script>
        
        
    </head>
<body>

<?php
	include_once('template/header.html');
	include('template/users.html');
	include_once('template/footer.html');
?>
</body>

</html>