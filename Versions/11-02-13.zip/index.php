<?php
    session_start();
	include('dbConnect.php');
    // categorie
	$query = mysql_query("SELECT * FROM categorie") or die(mysql_error());
	while($row = mysql_fetch_assoc($query))
	{
		$categorie .= '<li><a href="#">' . $row['nomeCat'] . '</a></li>';
	}
	// stampo ogni annuncio
	$query = mysql_query("SELECT * FROM users, project, categorie WHERE users.idUser = project.idUser AND categorie.idCat = project.categoria ORDER BY dataProj DESC") or die(mysql_error());
	if(mysql_num_rows($query) == 0)
	{
		$projects ='0 progetti.';
	}
	else
	{
		while($row = mysql_fetch_assoc($query))
		{
			$text = $row['descrizione'];
			$text = substr($text,0,350);
			// formattazione per ogni annuncio
			$projects .= 
				'<blockquote><div>
					<div>
						<a href="project.php?id=' . $row['idProj'] . '"><p>' . $row['nomeProj'] .'</p></a>
					</div>
					<div>
						<small>' . $row['nomeCat'] . '</small>
					</div>
					<div>
						<pre style="float:right;">' . $row['prezzo'] . '</pre>' . $text . '
					</div>
					<div>
						<small>' . $row['dataProj'] . '</small>
					</div>
				</div></blockquote><br/>';
		}
	}
	// fine stampa annuncio

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="it" xmlns="http://www.w3.org/1999/xhtml">
	<head>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Home page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
   		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" type="text/css" href="style/main.css" >
    </head>
    <body>
            <?php
				include('template/header.html');
			 	include('template/main.html'); 
				include('template/footer.html'); 
			?>
            <script src="bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>