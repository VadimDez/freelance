<?php

	if(include('check.php'))
	{
		if(isset($_GET['proj']))
		{
			$idProj = $_GET['proj'];
			
			include('dbConnect.php');
			
			// ottengo nome proj
			$query = mysql_query("SELECT nomeProj FROM project WHERE idProj = '$idProj' ") or die(mysql_error());
			if(mysql_num_rows($query))
			{
				$row = mysql_fetch_assoc($query);
				$nameProj = $row['nomeProj'];
				
				include('template/join.html');
			}
			else
			{
				header('Location:project.php');
			}
			mysql_close();
		}
		else
		{
			if(isset($_POST['join']) && isset($_POST['text']) && isset($_POST['proj']))
			{
				include('dbConnect.php');
				// commento
				$text = $_POST['text'];
				// parser
				
				$idUser = $_SESSION['idUser'];
				$idProj = $_POST['proj'];
				
				$query = mysql_query("INSERT INTO candidati(idProj, idUser, data, comment) VALUES('$idProj', '$idUser', now(), '$text')") or die(mysql_error());
				mysql_close();
				header('Location:project.php?id=' . $idProj);
			}
			else
			{
				header('Location:project.php');
			}
		}
	}
	else
	{
		header('Location:login.php');
	}

?>