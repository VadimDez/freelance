<?php
	session_start();
	if(isset($_GET['id']))
	{
		  $idUser = $_GET['id'];
	}
	else
	{
		if(isset($_SESSION['idUser']))
		{
			$idUser = $_SESSION['idUser'];
		}
		else
		{
			header('location:index.php');
			exit();
		}
	}
	
	
	if($idUser)
	{
		include('dbConnect.php');
		$query = mysql_query("SELECT * FROM users WHERE idUser='$idUser'") or die(mysql_error());
		if(mysql_num_rows($query) == 0)
		{
			$risultato = "Error!";	
		}
		else
		{
			$row = mysql_fetch_assoc($query);
			$risultato = $row['about'];
		}
	}
	else
	{		
			header('location:index.php');
			exit();
	}
	
	
?>

<b>Su di me:</b><br/>
<?php print $risultato; ?>