<?php
	session_start();
	include('dbConnect.php');
	
	// variabili
	$projects = '';
	
	
	if(isset($_GET['id']))
	{
		// se passa id del progetto
		$idProj = $_GET['id'];
		
		$query = mysql_query("SELECT * FROM project,users WHERE idProj = '$idProj' AND project.idUser = users.idUser") or die(mysql_error());
		if(mysql_num_rows($query) == 0 )
		{
			$projects = "il prog. e' stato cancellato o non esiste";
		}
		else
		{
			$row = mysql_fetch_assoc($query);
			$nameOwner 		 = $row['name'];
			$secondnameOwner = $row['secondname'];
			$idOwner  		 = $row['idUser'];
			$imgOwner		 = $row['img'];
			
			$nameProj 		 = $row['nomeProj'];
			$descProj		 = $row['descrizione'];
			$richesteProj	 = $row['richieste'];
			
			// controllo per il tasto per candidarsi
			if(isset($_SESSION['idUser'])) // se ha gia fatto login
			{
				$idUser = $_SESSION['idUser'];
				// controllo se e' il proprietario
				$candidato = mysql_query("SELECT idUser FROM project WHERE idProj='$idProj' AND idUser='$idUser'") or die(mysql_error());
				if(mysql_num_rows($candidato) == 0)
				{
					$proprietario = false;
					// controllo se utente ha gia partecipato
					$candidato = mysql_query("SELECT idUser FROM candidati WHERE idProj='$idProj' AND idUser='$idUser'") or die(mysql_error());
					if(mysql_num_rows($candidato) == 0)
					{
						// non ha ancora partecipato - aggiungo bottone per candidarsi
						$projects .= '<a href="join.php?proj=' . $idProj . '"><input type="submit" value="Candidarsi"/></a>';
					}
					else
					{
						// sta partecipando - aggiungo bottone "esci"
						$projects .= '<a href="leave.php?proj=' . $idProj . '"><input type="submit" value="Esci"/></a>';
					}
				}
				else
				{
					$proprietario = true;
				}
			
			}
			
			$comments = '';
			$query = mysql_query("SELECT * FROM candidati, users WHERE idProj='$idProj' AND candidati.idUser = users.idUser") or die(mysql_error());
			if(mysql_num_rows($query) == 0)
			{
				// in caso se non ci sono proposte
				$comments .= "Non ci sono proposte";	
			}
			else
			{
				
					if($proprietario)
					{
						// controllo se proprietario ha gia' sceglto il candidato
						$controllo = mysql_query("SELECT idUser FROM vincenti WHERE idProj='$idProj'") or die(mysql_error());
						if(mysql_num_rows($controllo) < 1)
						{
							// se no:
							$decide = false;
						}
						else
						{
							// se si:
							$decide = true;
						}
					}
				
				// stampo i commenti , cioe' proposte
				while($row = mysql_fetch_assoc($query))
				{
					$comments .= '<div class="media">
						  <a class="pull-left" href="profile.php?id=' . $row['idUser'] .'">
							<img class="media-object" src="' . $row['img'] . '" width="64px">
						  </a>
						  <div class="media-body">
							<h4 class="media-heading">' . $row['name'] . ' ' . $row['secondname'] . '</h4>';
							if(!$decide && $proprietario == true)
							{
								$comments .= '<form action="take.php?proj=' . $idProj . '" method="post"><input type="hidden" value="' . $row['idUser'] . '" name="usr" /><input type="submit" value="Scegli" name="take"/></form>';
							}
							$comments .= $row['comment'] . '
						 
							<!-- Nested media object -->
							<div class="media">
							  <small>' . $row['data'] . '</small>
							</div>
						  </div>
						</div>';
				}
			}
			
		}
	}
	else
	{
		$query = mysql_query("SELECT * FROM project ORDER BY dataProj DESC") or die(mysql_error());
		if(mysql_num_rows($query) == 0 )
		{
			$projects = "non ci sono progetti da fare";
		}
		else
		{
			while($row = mysql_fetch_assoc($query))
			{
				// stampo la lista dei progetti
				$projects .= '<div><a href="project.php?id=' . $row['idProj'] . '">' . $row['nomeProj'] . '</a></div> <br/>';
			}
		}
	}
	mysql_close();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="it" xmlns="http://www.w3.org/1999/xhtml">
	<head>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title><?php if($nameProj)
		{
			print $nameProj;
		}
		else
		{
			print "Progetti";	
		}?>
		</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
   		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link rel="stylesheet" type="text/css" href="style/main.css" >
</head>
	<body>
    	<?php
		
		include('template/header.html');
		if(isset($_GET['id']))
		{
			include('template/project.html');
		}
		else
		{
			include('template/projects.html');
		}
		include('template/footer.html');
		
		?>
        
        
        <script type="text/javascript" src="script/jquery-1.8.3.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
    </body>

</html>